# package_processamento_imagem

Descripton:
O pacote package_processamento_imagem é usado para:
    Processing
        - Histogram matching
        - Structural similary
        - Resize image
    utils
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot histogram


## Installation 

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_processamento_imagem

```bash
pip install package_processamento_imagem
```

## Author
Fernando Flavio

## License
[MIT](https://choosealicense.com/licenses/mit/)